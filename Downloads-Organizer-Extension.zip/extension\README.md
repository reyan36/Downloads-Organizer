# Downloads Organizer — Chrome Extension

> Companion extension for [Downloads Organizer](https://github.com/reyan36/Downloads-Organizer). Automatically sorts your browser downloads into categorized subfolders **before** they land on disk — so Chrome never shows "Removed."

## How It Works

When you download a file, this extension intercepts Chrome's filename determination and routes the file into the correct subfolder:

| Download | Saved To |
|----------|----------|
| `setup.exe` | `Downloads/Installers/setup.exe` |
| `photo.jpg` | `Downloads/Images/photo.jpg` |
| `report.pdf` | `Downloads/Documents/report.pdf` |
| `song.mp3` | `Downloads/Audio/song.mp3` |

Chrome remains fully aware of the file's real location — clicking the download in the bar opens it normally. **No more "Removed" errors.**

## Installation

1. Download or clone this folder
2. Open `chrome://extensions/` in Chrome
3. Enable **Developer Mode** (top-right toggle)
4. Click **Load Unpacked** → select this `Downloads-Organizer-Extension` folder
5. The extension icon appears in your toolbar — click it to toggle on/off

## Permissions

| Permission | Why |
|------------|-----|
| `downloads` | Intercept download filenames to organize into subfolders |
| `storage` | Save your enable/disable preference |

No network access. No browsing history. No content scripts.

## Compatibility

Works with any Chromium-based browser:
- Google Chrome
- Microsoft Edge
- Brave
- Opera / Vivaldi
